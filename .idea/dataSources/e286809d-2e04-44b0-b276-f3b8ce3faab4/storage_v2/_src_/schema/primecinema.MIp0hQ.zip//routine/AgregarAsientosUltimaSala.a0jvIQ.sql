create
    definer = root@localhost procedure AgregarAsientosUltimaSala()
BEGIN
    DECLARE last_sala_id INT;
    
    -- Obtener el último id_salas
    SELECT MAX(id_salas) INTO last_sala_id FROM salas;
    
    -- Llamar al procedimiento almacenado AgregarAsientos
    CALL AgregarAsientos(last_sala_id);
END;

