create
    definer = root@localhost procedure AgregarAsientos(IN sala_id int)
BEGIN
    DECLARE fila CHAR(1);
    DECLARE columna INT;
    DECLARE contador INT DEFAULT 0;
    DECLARE asiento_nombre VARCHAR(5);

    WHILE contador < 40 DO
        SET fila = CHAR(65 + FLOOR(contador / 5)); -- 65 es el código ASCII para 'A'
        SET columna = contador % 5 + 1;
        SET asiento_nombre = CONCAT(fila, '-', columna);

        INSERT INTO asientos (numero_asiento, id_salas)
        VALUES (asiento_nombre, sala_id);
        
        SET contador = contador + 1;
    END WHILE;
END;

