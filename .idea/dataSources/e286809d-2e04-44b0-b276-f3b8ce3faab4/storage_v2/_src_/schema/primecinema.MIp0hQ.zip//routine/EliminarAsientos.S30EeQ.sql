create
    definer = root@localhost procedure EliminarAsientos(IN sala_id int)
BEGIN
    DELETE FROM asientos WHERE id_salas = sala_id;
END;

